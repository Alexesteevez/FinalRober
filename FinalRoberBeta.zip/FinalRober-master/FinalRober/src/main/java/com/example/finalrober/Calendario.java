package com.example.finalrober;

import javafx.fxml.FXML;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;

import java.time.LocalDate;
import java.util.Calendar;
import java.util.List;

public class Calendario {

    @FXML
    private Calendar calendar;
    private Proyectos proyectos;
    private List<Proyectos> listaProyectos;

    @FXML
    public void initialize(){

            }
}
