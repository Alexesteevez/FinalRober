package com.example.finalrober;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Proyectos {
    private int id;
    private String categoria;
    private String titulo;
    private LocalDate fecha;
    private String estado;
    private List<Tarea> tareas;

    public Proyectos(int id, String categoria, String titulo, LocalDate fecha, String estado) {
        this.id = id;
        this.categoria = categoria;
        this.titulo = titulo;
        this.fecha = fecha;
        this.estado = estado;
        this.tareas = new ArrayList<>();
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public List<Tarea> getTareas() {
        return tareas;
    }

    public void agregarTarea(Tarea tarea) {
        tareas.add(tarea);
    }

    public void eliminarTarea(Tarea tarea) {
        tareas.remove(tarea);
    }
}
