package com.example.finalrober;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.util.Callback;
import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;

public class VerTodo implements Initializable {

    @FXML
    private AnchorPane anchorPanePrincipal;
    @FXML
    private Button btnAnadir, btnBorrar, btnEditar, btnAbrir;
    @FXML
    private DatePicker datePicker;
    @FXML
    private TableView<Proyectos> tabla;
    @FXML
    private TextField tfCategoria, tfTitulo;
    @FXML
    private TableColumn colID, colTitulo, colCategoria, colEstado, colFecha;
    @FXML
    private ComboBox<String> comboEstado;
    private ObservableList<Proyectos> proyectos;
    private int id = 1;

    private Proyectos proyecto;


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        // Inicializar el ComboBox con los valores posibles del estado
        comboEstado.setItems(FXCollections.observableArrayList("Pendiente", "En progreso", "Completo"));

        // Crear proyectos predeterminados
        Proyectos proyecto1 = new Proyectos(1, "Desarrollo de aplicación móvil", "Proyecto Alpha", LocalDate.of(2024, 3, 15), "En progreso");
        proyecto1.agregarTarea(new Tarea("Diseñar la interfaz de usuario"));
        proyecto1.agregarTarea(new Tarea("Implementar la lógica de negocio"));
        proyecto1.agregarTarea(new Tarea("Realizar pruebas de funcionamiento"));

        Proyectos proyecto2 = new Proyectos(2, "Creación de sitio web", "Proyecto Beta", LocalDate.of(2024, 3, 20), "Pendiente");
        proyecto2.agregarTarea(new Tarea("Diseñar la estructura de la página principal"));
        proyecto2.agregarTarea(new Tarea("Desarrollar la funcionalidad de registro de usuarios"));

        Proyectos proyecto3 = new Proyectos(3, "Gestión de inventario", "Proyecto Gamma", LocalDate.of(2024, 3, 25), "Completo");
        proyecto3.agregarTarea(new Tarea("Analizar los requisitos del cliente"));
        proyecto3.agregarTarea(new Tarea("Implementar la base de datos"));

        Proyectos proyecto4 = new Proyectos(4, "Planificación de eventos", "Proyecto Delta", LocalDate.of(2024, 3, 30), "Pendiente");
        proyecto4.agregarTarea(new Tarea("Buscar proveedores"));
        proyecto4.agregarTarea(new Tarea("Elaborar el presupuesto"));

        Proyectos proyecto5 = new Proyectos(5, "Desarrollo de videojuego", "Proyecto Épsilon", LocalDate.of(2024, 4, 5), "En progreso");
        proyecto5.agregarTarea(new Tarea("Diseñar los personajes"));
        proyecto5.agregarTarea(new Tarea("Implementar los controles del jugador"));

        // Agregar los proyectos a la lista de proyectos
        proyectos = FXCollections.observableArrayList(proyecto1, proyecto2, proyecto3, proyecto4, proyecto5);

        this.colID.setCellValueFactory(new PropertyValueFactory<>("id"));
        this.colTitulo.setCellValueFactory(new PropertyValueFactory<>("titulo"));
        this.colCategoria.setCellValueFactory(new PropertyValueFactory<>("categoria"));
        this.colFecha.setCellValueFactory(new PropertyValueFactory<>("fecha"));
        this.colEstado.setCellValueFactory(new PropertyValueFactory<>("estado"));

        // Configurar el cell factory para la columna colEstado
        colEstado.setCellFactory(new Callback<TableColumn<Proyectos, String>, TableCell<Proyectos, String>>() {
            @Override
            public TableCell<Proyectos, String> call(TableColumn<Proyectos, String> tareaStringTableColumn) {
                return new TableCell<Proyectos, String>() {
                    @Override
                    protected void updateItem(String estado, boolean empty) {
                        super.updateItem(estado, empty);
                        if (empty || estado == null) {
                            setText(null);
                            setStyle("");
                        } else {
                            setText(estado);

                            // Cambiar el color de fondo y la letra según el estado
                            if ("Pendiente".equals(estado)) {
                                setTextFill(Color.web("#660000")); // Rojo oscuro
                                setStyle("-fx-background-color: #FFCCCC;"); // Rojo claro
                            } else if ("En progreso".equals(estado)) {
                                setTextFill(Color.web("#663300")); // Naranja oscuro
                                setStyle("-fx-background-color: #FFD699;"); // Naranja claro
                            } else if ("Completo".equals(estado)) {
                                setTextFill(Color.web("#006600")); // Verde oscuro
                                setStyle("-fx-background-color: #CCFFCC;"); // Verde claro
                            }
                        }
                    }
                };
            }
        });

        // Agregar proyectos a la tabla
        tabla.setItems(proyectos);
    }
    @FXML
    void abrir(ActionEvent event) {
        try {
            // Obtener el proyecto seleccionado en la tabla
            Proyectos proyectoSeleccionado = tabla.getSelectionModel().getSelectedItem();

            if (proyectoSeleccionado != null) {
                // Cargar el archivo FXML de la nueva escena
                FXMLLoader loader = new FXMLLoader(getClass().getResource("nuevo.fxml"));
                Parent root = loader.load();

                // Obtener el controlador de la ventana de nuevo
                Nuevo nuevoController = loader.getController();

                // Configurar el proyecto seleccionado en el controlador de la ventana de nuevo
                nuevoController.setProyecto(proyectoSeleccionado);

                // Configurar las tareas del proyecto seleccionado en el controlador de la ventana de nuevo
                nuevoController.setTareas(proyectoSeleccionado.getTareas());

                // Crear una nueva escena
                Scene scene = new Scene(root);
                Stage stage = new Stage();
                stage.setScene(scene);
                stage.setTitle("Nueva Tarea");
                stage.show();
            } else {
                // Mostrar un mensaje de error si no se ha seleccionado ningún proyecto
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setHeaderText(null);
                alert.setTitle("Error");
                alert.setContentText("Seleccione un proyecto para abrir");
                alert.showAndWait();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    void guardar(ActionEvent event) {
        try {
            String titulo = this.tfTitulo.getText();
            String categoria = this.tfCategoria.getText();
            LocalDate fecha = this.datePicker.getValue();
            String estado = comboEstado.getValue(); // Obtener el estado del ComboBox

            Proyectos p = new Proyectos(id++, titulo, categoria, fecha, estado);

            if (!this.proyectos.contains(p)) {
                this.proyectos.add(p);
            } else {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setHeaderText(null);
                alert.setTitle("Error");
                alert.setContentText("Este elemento ya existe");
                alert.showAndWait();
            }
            // Actualizar la tabla
            this.tabla.setItems(proyectos);
            limpiarCampos();
        } catch (NumberFormatException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText(null);
            alert.setTitle("Error");
            alert.setContentText("Formato incorrecto");
            alert.showAndWait();
        }
    }

    @FXML
    void editar(ActionEvent event) {
        // Obtener la tarea seleccionada en la tabla
        Proyectos proyectosSeleccionada = tabla.getSelectionModel().getSelectedItem();
        if (proyectosSeleccionada == null) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText(null);
            alert.setTitle("Error");
            alert.setContentText("Seleccione una tarea para editar");
            alert.showAndWait();
            return;
        }

        // Actualizar los datos de la tarea seleccionada
        proyectosSeleccionada.setTitulo(tfTitulo.getText());
        proyectosSeleccionada.setCategoria(tfCategoria.getText());
        proyectosSeleccionada.setFecha(datePicker.getValue());
        proyectosSeleccionada.setEstado(comboEstado.getValue());

        // Actualizar la tabla
        tabla.refresh();
        limpiarCampos();
    }
    @FXML
    void borrar(ActionEvent event) {
        // Obtener la tarea seleccionada en la tabla
        Proyectos proyectosSeleccionada = tabla.getSelectionModel().getSelectedItem();
        if (proyectosSeleccionada != null) {
            // Eliminar la tarea de la lista de tareas
            proyectos.remove(proyectosSeleccionada);
            // Actualizar la tabla
            tabla.setItems(proyectos);
            limpiarCampos();
        } else {
            // Si no se ha seleccionado ninguna tarea, mostrar un mensaje de error
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText(null);
            alert.setTitle("Error");
            alert.setContentText("Selecciona una tarea para borrar");
            alert.showAndWait();
        }
    }

    // Método para limpiar todos los campos
    private void limpiarCampos() {
        tfCategoria.clear();
        tfTitulo.clear();
        datePicker.setValue(null);
        comboEstado.getSelectionModel().clearSelection();
    }
    public int contarCompletas() {
        int count = 0;
        for (Proyectos proyectos : this.proyectos) {
            if ("Completo".equals(proyectos.getEstado())) {
                count++;
            }
        }
        return count;
    }

    public int contarEnProgreso() {
        int count = 0;
        for (Proyectos proyectos : this.proyectos) {
            if ("En progreso".equals(proyectos.getEstado())) {
                count++;
            }
        }
        return count;
    }

    public int contarPendientes() {
        int count = 0;
        for (Proyectos proyectos : this.proyectos) {
            if ("Pendiente".equals(proyectos.getEstado())) {
                count++;
            }
        }
        return count;
    }
    public void actualizarTabla() {
        tabla.setItems(proyectos);
    }
    public AnchorPane getAnchorPanePrincipal() {
        return anchorPanePrincipal;
    }
}
