package com.example.finalrober;

import com.example.finalrober.Proyectos;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;

import java.util.List;

public class Nuevo {

    @FXML
    private AnchorPane anchorPanePrincipal;
    @FXML
    private Button btnAnadirTarea;
    @FXML
    private Button btnBorrarTarea;
    @FXML
    private TableColumn<Tarea, String> colTareas;
    @FXML
    private Label lbCategoria;
    @FXML
    private Label lbEstado;
    @FXML
    private Label lbFecha;
    @FXML
    private Label lbTitulo;
    @FXML
    private TableView<Tarea> tablaTareas;
    @FXML
    private TextField tfNombreTarea;

    private ObservableList<Tarea> tareas;

    // Referencia al proyecto actual
    private Proyectos proyecto;

    // Método para configurar el proyecto actual
    public void setProyecto(Proyectos proyecto) {
        this.proyecto = proyecto;

        if (proyecto != null) {
            // Configurar las etiquetas con la información del proyecto
            lbTitulo.setText(proyecto.getTitulo());
            lbCategoria.setText(proyecto.getCategoria());
            lbFecha.setText(proyecto.getFecha().toString());
            lbEstado.setText(proyecto.getEstado());

            // Configurar la tabla de tareas con las tareas del proyecto
            if (proyecto.getTareas() != null) {
                tareas.addAll(proyecto.getTareas());
                tablaTareas.setItems(tareas);
            }
        }
    }
    public void setTareas(List<Tarea> tareas) {
        this.tareas.clear();
        this.tareas.addAll(tareas);
        tablaTareas.setItems(this.tareas);
    }
    @FXML
    void initialize() {
        tareas = FXCollections.observableArrayList();

        this.colTareas.setCellValueFactory(new PropertyValueFactory("nombre"));
    }
    @FXML
    void borrarNombreTarea(ActionEvent event) {
        try {
            // Obtener la tarea seleccionada en la tabla de tareas
            Tarea tareaSeleccionada = tablaTareas.getSelectionModel().getSelectedItem();

            if (tareaSeleccionada != null) {
                // Eliminar la tarea de la lista de tareas
                tareas.remove(tareaSeleccionada);

                // Actualizar la tabla de tareas
                tablaTareas.setItems(tareas);
            } else {
                // Mostrar un mensaje de error si no se ha seleccionado ninguna tarea
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setHeaderText(null);
                alert.setTitle("Error");
                alert.setContentText("Seleccione una tarea para borrar");
                alert.showAndWait();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @FXML
    void guardarNombreTarea(ActionEvent event) {
        try {
            String nombreTarea = tfNombreTarea.getText();

            Tarea t = new Tarea(nombreTarea);

            if(!this.tareas.contains(t)){
                this.tareas.add(t);
            } else {
                // Mostrar un mensaje de error si el campo de texto está vacío
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setHeaderText(null);
                alert.setTitle("Error");
                alert.setContentText("Ingrese un nombre para la tarea");
                alert.showAndWait();
            }
            this.tablaTareas.setItems(tareas);
            tfNombreTarea.clear();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


}
